# Reference

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ref_type** | [**ReferenceType**](ReferenceType.md) |  | [optional] 
**span_id** | [**SpanID**](SpanID.md) |  | [optional] 
**trace_id** | [**TraceID**](TraceID.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

