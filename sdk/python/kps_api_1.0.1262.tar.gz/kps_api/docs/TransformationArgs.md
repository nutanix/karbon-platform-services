# TransformationArgs

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**args** | [**list[ScriptParamValue]**](ScriptParamValue.md) | Array of script param values for the transformation | 
**transformation_id** | **str** | ID for the transformation | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

