# Iter8Criteria

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**metric** | **str** |  | [optional] 
**sample_size** | **int** |  | [optional] 
**stop_on_failure** | **bool** |  | [optional] 
**tolerance** | **float** |  | [optional] 
**tolerance_type** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

