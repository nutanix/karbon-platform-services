# EdgeCertLockParam

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**duration_seconds** | **int** | If Locked is false and DurationSeconds is greater than 0, then first unlock the edge certification, then auto lock it after DurationSeconds seconds. | [optional] 
**edge_cluster_id** | **str** |  | 
**locked** | **bool** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

