# Iter8ExperimentItem

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**assessment_conclusion** | **list[str]** |  | [optional] 
**baseline** | **str** |  | [optional] 
**baseline_percentage** | **int** |  | [optional] 
**candidate** | **str** |  | [optional] 
**candidate_percentage** | **int** |  | [optional] 
**created_at** | **int** |  | [optional] 
**ended_at** | **int** |  | [optional] 
**name** | **str** |  | [optional] 
**namespace** | **str** |  | [optional] 
**phase** | **str** |  | [optional] 
**started_at** | **int** |  | [optional] 
**status** | **str** |  | [optional] 
**target_service** | **str** |  | [optional] 
**target_service_namespace** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

