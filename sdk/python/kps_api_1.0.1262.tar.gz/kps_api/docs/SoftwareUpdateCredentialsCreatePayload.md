# SoftwareUpdateCredentialsCreatePayload

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**access_type** | [**SoftwareUpdateCredentialsAccessType**](SoftwareUpdateCredentialsAccessType.md) |  | 
**batch_id** | **str** |  | 
**credentials** | **dict(str, str)** | Details of the credentials | [optional] 
**release** | **str** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

