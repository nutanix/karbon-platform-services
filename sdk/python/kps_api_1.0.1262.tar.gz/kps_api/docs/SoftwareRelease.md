# SoftwareRelease

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**changelog** | **str** | The changes that were made in this release from the previous release | 
**release** | **str** | This is the release that is avaliable | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

