# APIErrorPayload

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**error_code** | **int** | Karbon Platform Services API error code | 
**message** | **str** | Error message | 
**status_code** | **int** | HTTP status code for the response | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

