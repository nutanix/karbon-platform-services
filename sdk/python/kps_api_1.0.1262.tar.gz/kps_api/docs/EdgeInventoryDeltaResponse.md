# EdgeInventoryDeltaResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**created** | [**EdgeInventoryDetails**](EdgeInventoryDetails.md) |  | [optional] 
**deleted** | [**EdgeInventoryDeleted**](EdgeInventoryDeleted.md) |  | [optional] 
**updated** | [**EdgeInventoryDetails**](EdgeInventoryDetails.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

