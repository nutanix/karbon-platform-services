# JaegerInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**enabled** | **bool** |  | [optional] 
**integration** | **bool** |  | [optional] 
**namespace_selector** | **bool** |  | [optional] 
**url** | **str** |  | [optional] 
**white_list_istio_system** | **list[str]** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

