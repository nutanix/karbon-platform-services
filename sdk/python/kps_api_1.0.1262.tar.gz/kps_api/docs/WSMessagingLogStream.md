# WSMessagingLogStream

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**log_stream_info** | [**LogStream**](LogStream.md) |  | [optional] 
**project_id** | **str** |  | [optional] 
**url** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

