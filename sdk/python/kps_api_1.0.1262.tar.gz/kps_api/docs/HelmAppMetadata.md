# HelmAppMetadata

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**crds** | **str** | Helm chart CRDs as a string | [optional] 
**metadata** | **str** |  | 
**values** | **str** | values.yaml as a string | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

