# Iter8CriteriaDetail

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**criteria** | [**Iter8Criteria**](Iter8Criteria.md) |  | [optional] 
**metric** | [**Iter8Metric**](Iter8Metric.md) |  | [optional] 
**name** | **str** |  | [optional] 
**status** | [**Iter8SuccessCrideriaStatus**](Iter8SuccessCrideriaStatus.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

