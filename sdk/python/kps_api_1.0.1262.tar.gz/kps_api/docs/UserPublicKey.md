# UserPublicKey

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**created_at** | **datetime** | created at timestamp | 
**id** | **str** | ID of the user | 
**public_key** | **str** | Public Key of the user | 
**tenant_id** | **str** | Tenant ID of the user | 
**updated_at** | **datetime** | updated at timestamp | 
**used_at** | **datetime** | last used timestamp | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

