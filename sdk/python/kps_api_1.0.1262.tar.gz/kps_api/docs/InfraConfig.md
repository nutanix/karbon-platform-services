# InfraConfig

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cluster_config** | [**ClusterConfig**](ClusterConfig.md) |  | 
**k8s_config** | [**K8sConfig**](K8sConfig.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

