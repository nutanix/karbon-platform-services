# IstioValidationSummary

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**errors** | **int** | Number of validations with error severity | 
**object_count** | **int** | Number of Istio Objects analyzed | 
**warnings** | **int** | Number of validations with warning severity | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

