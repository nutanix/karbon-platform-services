# LogCollectorKinesis

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**dest** | **str** | Destination for log collection (url or region) | 
**stream** | **str** | Stream name | 
**type** | [**LogCollectorKinesisType**](LogCollectorKinesisType.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

