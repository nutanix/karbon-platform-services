# WorkloadList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**namespace** | [**Namespace**](Namespace.md) |  | 
**workloads** | [**list[WorkloadListItem]**](WorkloadListItem.md) | Workloads for a given namespace | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

