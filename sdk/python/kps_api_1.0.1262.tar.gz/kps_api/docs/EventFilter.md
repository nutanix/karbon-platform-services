# EventFilter

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**end_time** | **datetime** |  | [optional] 
**keys** | **dict(str, str)** |  | [optional] 
**path** | **str** |  | 
**size** | **int** |  | [optional] 
**start** | **int** |  | [optional] 
**start_time** | **datetime** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

