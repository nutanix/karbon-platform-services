# ServiceClassSchemas

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**svc_binding** | [**ServiceBindingSchema**](ServiceBindingSchema.md) |  | [optional] 
**svc_instance** | [**ServiceInstanceSchema**](ServiceInstanceSchema.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

