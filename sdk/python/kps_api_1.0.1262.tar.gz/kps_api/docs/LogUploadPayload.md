# LogUploadPayload

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**application_id** | **str** | Optional ID of the application for which the log will be collected | [optional] 
**batch_id** | **str** | Batch ID of the log upload request | 
**url** | **str** | URL where the log will be uploaded by the edge | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

