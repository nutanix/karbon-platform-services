# ServicesOverview

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**detail** | [**ServiceDetails**](ServiceDetails.md) |  | [optional] 
**graph** | [**GraphConfig**](GraphConfig.md) |  | [optional] 
**health** | [**ServiceHealth**](ServiceHealth.md) |  | [optional] 
**inbound** | [**DashboardResponse**](DashboardResponse.md) |  | [optional] 
**outbound** | [**DashboardResponse**](DashboardResponse.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

