# IstioCheck

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**message** | **str** | Description of the check | 
**path** | **str** | String that describes where in the yaml file is the check located | [optional] 
**severity** | [**SeverityLevel**](SeverityLevel.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

