# ClusterRbacConfigSpec

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**exclusion** | **object** |  | [optional] 
**inclusion** | **object** |  | [optional] 
**mode** | **object** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

