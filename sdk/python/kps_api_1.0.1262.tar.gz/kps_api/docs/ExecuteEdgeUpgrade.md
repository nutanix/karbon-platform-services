# ExecuteEdgeUpgrade

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**edge_ids** | **list[str]** | List of edge IDs to upgrade | 
**release** | **str** | Version to upgrade to, for the execute edge upgrade. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

