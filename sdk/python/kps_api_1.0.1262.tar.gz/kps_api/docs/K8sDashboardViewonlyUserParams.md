# K8sDashboardViewonlyUserParams

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**user_ids** | **list[str]** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

