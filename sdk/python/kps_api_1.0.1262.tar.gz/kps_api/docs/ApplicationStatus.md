# ApplicationStatus

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**app_status** | [**AppStatus**](AppStatus.md) |  | 
**application_id** | **str** |  | 
**edge_id** | **str** |  | 
**tenant_id** | **str** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

