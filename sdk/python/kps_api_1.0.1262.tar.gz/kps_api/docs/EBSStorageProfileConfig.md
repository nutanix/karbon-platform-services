# EBSStorageProfileConfig

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**encrypted** | **str** |  | 
**iops_per_gb** | **str** |  | 
**type** | **str** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

