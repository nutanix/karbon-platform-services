# ProtocolTraffic

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**protocol** | **str** |  | [optional] 
**rates** | **dict(str, str)** |  | [optional] 
**responses** | [**Responses**](Responses.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

