# ContainerRegistryInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**email** | **str** | Email address for the container registry profile user. | 
**pwd** | **str** | Password for the container registry profile. | 
**user_name** | **str** | User name for the container registry profile. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

