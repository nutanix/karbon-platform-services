# RequestLogUploadPayload

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**application_id** | **str** | Optional ID of the application for which the log will be collected | [optional] 
**edge_ids** | **list[str]** | IDs of the edges from where the logs will be collected | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

