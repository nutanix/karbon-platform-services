# Iter8SuccessCrideriaStatus

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**abort_experiment** | **bool** |  | [optional] 
**conclusions** | **list[str]** |  | [optional] 
**success_criterion_met** | **bool** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

