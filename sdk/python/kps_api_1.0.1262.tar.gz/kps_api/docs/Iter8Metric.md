# Iter8Metric

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**absent_value** | **str** |  | [optional] 
**is_counter** | **bool** |  | [optional] 
**query_template** | **str** |  | [optional] 
**sample_size_template** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

