# HelmTemplateResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**app_manifest** | **str** |  | 
**crds** | **str** | contains helm Custom Resource Definitions string | [optional] 
**metadata** | **str** |  | 
**values** | **str** | contains values.yaml string | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

