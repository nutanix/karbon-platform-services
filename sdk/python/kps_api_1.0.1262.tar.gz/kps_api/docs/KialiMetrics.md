# KialiMetrics

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**histograms** | **dict(str, dict(str, KialiMetric))** |  | [optional] 
**metrics** | [**dict(str, KialiMetric)**](KialiMetric.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

