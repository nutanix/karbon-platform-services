# ServiceBindingParam

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**bind_resource** | [**ServiceBindingResource**](ServiceBindingResource.md) |  | [optional] 
**description** | **str** |  | [optional] 
**id** | **str** |  | [optional] 
**name** | **str** |  | 
**parameters** | **dict(str, object)** |  | [optional] 
**svc_class_id** | **str** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

