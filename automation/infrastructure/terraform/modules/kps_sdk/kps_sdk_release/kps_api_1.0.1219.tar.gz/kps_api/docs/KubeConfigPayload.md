# KubeConfigPayload

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**kubeconfig** | **str** | string representation of kubeconfig yaml | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

