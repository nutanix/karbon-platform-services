# WorkloadOverview

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**detail** | [**Workload**](Workload.md) |  | [optional] 
**graph** | [**GraphConfig**](GraphConfig.md) |  | [optional] 
**health** | [**WorkloadHealth**](WorkloadHealth.md) |  | [optional] 
**inbound** | [**DashboardResponse**](DashboardResponse.md) |  | [optional] 
**outbound** | [**DashboardResponse**](DashboardResponse.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

