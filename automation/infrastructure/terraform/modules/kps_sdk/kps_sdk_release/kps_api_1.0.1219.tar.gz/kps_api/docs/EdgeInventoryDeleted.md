# EdgeInventoryDeleted

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**applications** | **list[str]** |  | [optional] 
**categories** | **list[str]** |  | [optional] 
**cloud_profiles** | **list[str]** |  | [optional] 
**container_registries** | **list[str]** |  | [optional] 
**data_pipelines** | **list[str]** |  | [optional] 
**data_sources** | **list[str]** |  | [optional] 
**functions** | **list[str]** |  | [optional] 
**log_collectors** | **list[str]** |  | [optional] 
**ml_models** | **list[str]** |  | [optional] 
**project_services** | **list[str]** |  | [optional] 
**projects** | **list[str]** |  | [optional] 
**runtime_environments** | **list[str]** |  | [optional] 
**software_updates** | **list[str]** |  | [optional] 
**svc_bindings** | **list[str]** |  | [optional] 
**svc_instances** | **list[str]** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

