# Log

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**fields** | [**list[KeyValue]**](KeyValue.md) |  | [optional] 
**timestamp** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

