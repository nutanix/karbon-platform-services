# AppStatus

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**image_list** | **list[str]** |  | [optional] 
**pod_metrics_list** | [**list[PodMetrics]**](PodMetrics.md) |  | [optional] 
**pod_status_list** | [**list[PodStatus]**](PodStatus.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

