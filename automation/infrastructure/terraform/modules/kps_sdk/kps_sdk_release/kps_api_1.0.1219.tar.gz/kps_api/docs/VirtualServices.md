# VirtualServices

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**items** | [**list[VirtualService]**](VirtualService.md) |  | [optional] 
**permissions** | [**ResourcePermissions**](ResourcePermissions.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

