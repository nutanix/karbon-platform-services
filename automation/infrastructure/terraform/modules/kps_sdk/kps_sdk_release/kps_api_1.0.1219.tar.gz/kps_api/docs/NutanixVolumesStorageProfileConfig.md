# NutanixVolumesStorageProfileConfig

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data_services_ip** | **str** |  | 
**data_services_port** | **int** |  | 
**flash_mode** | **bool** |  | [optional] 
**prism_element_cluster_port** | **int** |  | 
**prism_element_cluster_vip** | **str** |  | 
**prism_element_password** | **str** |  | 
**prism_element_user_name** | **str** |  | 
**storage_container_name** | **str** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

