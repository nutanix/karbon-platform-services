# ExecuteEdgeUpgradeID

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**release** | **str** | Version to upgrade to, for the execute edge upgrade. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

