# WorkloadItem

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**istio_sidecar** | **bool** | Define if all Pods related to the Workload has an IstioSidecar deployed | 
**workload_name** | **str** | Name of a workload member of an application | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

