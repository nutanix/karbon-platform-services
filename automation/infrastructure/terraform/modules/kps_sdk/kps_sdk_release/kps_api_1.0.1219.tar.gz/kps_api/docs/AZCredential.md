# AZCredential

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**storage_account_name** | **str** |  | 
**storage_key** | **str** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

