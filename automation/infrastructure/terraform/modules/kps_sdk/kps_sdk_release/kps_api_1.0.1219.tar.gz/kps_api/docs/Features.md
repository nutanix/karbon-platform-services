# Features

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**download_and_upgrade** | **bool** |  | [optional] 
**high_mem_alert** | **bool** |  | [optional] 
**multi_node_aware** | **bool** |  | [optional] 
**real_time_logs** | **bool** |  | [optional] 
**remote_ssh** | **bool** |  | [optional] 
**url_upgrade** | **bool** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

