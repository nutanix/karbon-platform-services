# AppListItem

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**istio_sidecar** | **bool** | Define if all Pods related to the Workloads of this app has an IstioSidecar deployed | 
**labels** | **dict(str, str)** | Labels for App | [optional] 
**name** | **str** | Name of the application | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

