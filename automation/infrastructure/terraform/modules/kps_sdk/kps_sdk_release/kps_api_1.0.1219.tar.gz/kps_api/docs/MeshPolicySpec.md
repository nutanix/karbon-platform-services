# MeshPolicySpec

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**origin_is_optional** | **object** |  | [optional] 
**origins** | **object** |  | [optional] 
**peer_is_optional** | **object** |  | [optional] 
**peers** | **object** |  | [optional] 
**principal_binding** | **object** |  | [optional] 
**targets** | **object** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

