# LogCollectorCloudwatch

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**dest** | **str** | Destination for log collection (url or region) | 
**group** | **str** | Stream name | 
**stream** | **str** | Stream name | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

