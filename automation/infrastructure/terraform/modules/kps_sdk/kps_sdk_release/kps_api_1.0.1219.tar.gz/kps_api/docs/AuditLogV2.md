# AuditLogV2

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**modifier_id** | **str** |  | [optional] 
**modifier_name** | **str** |  | [optional] 
**modifier_role** | **str** |  | [optional] 
**operation** | **str** |  | [optional] 
**operation_type** | **str** |  | [optional] 
**payload** | **str** |  | [optional] 
**project_id** | **str** |  | [optional] 
**project_name** | **str** |  | [optional] 
**resource_id** | **str** |  | [optional] 
**resource_name** | **str** |  | [optional] 
**resource_type** | **str** |  | [optional] 
**scope** | **str** |  | [optional] 
**service_domain_id** | **str** |  | [optional] 
**service_domain_name** | **str** |  | [optional] 
**tenant_id** | **str** |  | [optional] 
**timestamp** | **datetime** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

