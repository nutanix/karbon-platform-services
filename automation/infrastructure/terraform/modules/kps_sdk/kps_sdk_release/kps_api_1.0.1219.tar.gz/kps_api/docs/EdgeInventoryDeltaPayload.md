# EdgeInventoryDeltaPayload

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**applications** | [**list[EntityVersionMetadata]**](EntityVersionMetadata.md) |  | [optional] 
**categories** | [**list[EntityVersionMetadata]**](EntityVersionMetadata.md) |  | [optional] 
**cloud_profiles** | [**list[EntityVersionMetadata]**](EntityVersionMetadata.md) |  | [optional] 
**container_registries** | [**list[EntityVersionMetadata]**](EntityVersionMetadata.md) |  | [optional] 
**data_pipelines** | [**list[EntityVersionMetadata]**](EntityVersionMetadata.md) |  | [optional] 
**data_sources** | [**list[EntityVersionMetadata]**](EntityVersionMetadata.md) |  | [optional] 
**functions** | [**list[EntityVersionMetadata]**](EntityVersionMetadata.md) |  | [optional] 
**log_collectors** | [**list[EntityVersionMetadata]**](EntityVersionMetadata.md) |  | [optional] 
**ml_models** | [**list[EntityVersionMetadata]**](EntityVersionMetadata.md) |  | [optional] 
**project_services** | [**list[EntityVersionMetadata]**](EntityVersionMetadata.md) |  | [optional] 
**projects** | [**list[EntityVersionMetadata]**](EntityVersionMetadata.md) |  | [optional] 
**runtime_environments** | [**list[EntityVersionMetadata]**](EntityVersionMetadata.md) |  | [optional] 
**software_updates** | [**list[EntityVersionMetadata]**](EntityVersionMetadata.md) |  | [optional] 
**svc_bindings** | [**list[EntityVersionMetadata]**](EntityVersionMetadata.md) |  | [optional] 
**svc_instances** | [**list[EntityVersionMetadata]**](EntityVersionMetadata.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

