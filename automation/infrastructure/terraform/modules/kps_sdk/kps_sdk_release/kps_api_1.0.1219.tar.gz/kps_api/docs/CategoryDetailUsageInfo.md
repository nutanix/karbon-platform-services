# CategoryDetailUsageInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** | ID of the category | 
**usage_map** | [**dict(str, CategoryUsage)**](CategoryUsage.md) | UsageMap map of category value to its usage | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

