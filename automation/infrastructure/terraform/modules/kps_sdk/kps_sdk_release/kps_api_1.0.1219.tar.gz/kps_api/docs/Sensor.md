# Sensor

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**edge_id** | **str** | ID of the edge this entity belongs to | 
**id** | **str** | ID of the entity Maximum character length is 64 for project, category, and runtime environment, 36 for other entity types. | [optional] 
**topic_name** | **str** | mqtt topic name that identifies the sensor. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

