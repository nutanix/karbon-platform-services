# MonitoringDashboardExternalLinkVariables

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**app** | **str** |  | [optional] 
**namespace** | **str** |  | [optional] 
**service** | **str** |  | [optional] 
**version** | **str** |  | [optional] 
**workload** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

