# MonitoringDashboard

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**aggregations** | [**list[Aggregation]**](Aggregation.md) |  | [optional] 
**charts** | [**list[Chart]**](Chart.md) |  | [optional] 
**external_links** | [**list[ExternalLink]**](ExternalLink.md) |  | [optional] 
**title** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

