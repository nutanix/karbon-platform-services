# Iter8ExperimentDetail

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**criterias** | [**list[Iter8CriteriaDetail]**](Iter8CriteriaDetail.md) |  | [optional] 
**experiment_item** | [**Iter8ExperimentItem**](Iter8ExperimentItem.md) |  | [optional] 
**permissions** | [**ResourcePermissions**](ResourcePermissions.md) |  | [optional] 
**traffic_control** | [**Iter8TrafficControl**](Iter8TrafficControl.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

