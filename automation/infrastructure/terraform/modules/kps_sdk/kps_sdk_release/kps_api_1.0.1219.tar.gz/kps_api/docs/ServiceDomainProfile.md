# ServiceDomainProfile

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ai_inferencing_service** | [**AIInferencingServiceProfile**](AIInferencingServiceProfile.md) |  | [optional] 
**enable_ssh** | **bool** |  | [optional] 
**ingress_type** | **str** |  | [optional] 
**privileged** | **bool** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

