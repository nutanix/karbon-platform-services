# LogCollectorSources

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**categories** | **dict(str, str)** | List of categories to run on | [optional] 
**edges** | **list[str]** | List of edges to enable on | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

