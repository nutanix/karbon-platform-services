# DataPipelineContainers

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**container_names** | **list[str]** |  | [optional] 
**data_pipeline_id** | **str** |  | [optional] 
**edge_id** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

